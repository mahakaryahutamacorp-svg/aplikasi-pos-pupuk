╔════════════════════════════════════════════════════════════════════╗
║                                                                    ║
║       💚 CV. MAJU BERSAMA - SISTEM KASIR POS PORTABLE 💚          ║
║                                                                    ║
║              Toko Pupuk & Pestisida - Versi 1.0                   ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝

═══════════════════════════════════════════════════════════════════════
  🚀 CARA MENGGUNAKAN
═══════════════════════════════════════════════════════════════════════

  1. Double-click file "MajuBersamaPOS.html"
  2. Aplikasi akan terbuka di browser
  3. Selesai! Tidak perlu install apapun.

═══════════════════════════════════════════════════════════════════════
  ✨ FITUR APLIKASI
═══════════════════════════════════════════════════════════════════════

  🏠 Dashboard     - Ringkasan penjualan & stok
  🛒 Kasir         - Transaksi penjualan (tunai/hutang)
  📦 Produk        - Kelola stok pupuk & pestisida
  👥 Pelanggan     - Database pelanggan & hutang
  📊 Laporan       - Riwayat transaksi lengkap
  ⚙️ Pengaturan    - Backup/restore data

═══════════════════════════════════════════════════════════════════════
  💾 PENYIMPANAN DATA
═══════════════════════════════════════════════════════════════════════

  Data tersimpan di browser (localStorage).
  
  ⚠️ PENTING: 
  - Gunakan browser yang sama untuk konsistensi data
  - Backup data secara berkala via menu Pengaturan
  - Jangan hapus cache browser tanpa backup

═══════════════════════════════════════════════════════════════════════
  📁 STRUKTUR FOLDER
═══════════════════════════════════════════════════════════════════════

  CV.MajuBersama.POS/
  ├── MajuBersamaPOS.html  ← Klik 2x untuk buka
  ├── lib/                 ← Library pendukung
  └── README.txt           ← File ini

═══════════════════════════════════════════════════════════════════════
  📞 KONTAK
═══════════════════════════════════════════════════════════════════════

  CV. Maju Bersama
  Toko Pupuk & Pestisida
  
═══════════════════════════════════════════════════════════════════════

                     © 2026 CV. Maju Bersama
                      All rights reserved.
